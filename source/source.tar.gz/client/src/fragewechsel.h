#ifndef FRAGEWECHSEL_H
#define FRAGEWECHSEL_H

/**
 * ============================================================================
 * @file        : fragewechsel.h
 * @author      : Kathrin Holzmann
 * @date        : Jun 20, 2011
 * ============================================================================
 */

#include "../../common/src/messages.h"
#include "../../common/src/question.h"

void *fragen_thread(void *data);

#endif /*FRAGEWECHSEL_H*/